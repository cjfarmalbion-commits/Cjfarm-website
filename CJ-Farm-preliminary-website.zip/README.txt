CJ FARM PRELIMINARY WEBSITE

Files:
- index.html — complete one-page website

To use:
1. Upload index.html to your GitHub repository.
2. Commit the change.
3. Cloudflare Pages/Workers should publish the updated site using your existing setup.

The site includes:
- Responsive mobile/desktop design
- CJ Farm mission/about section
- Animal list
- Visit/community section
- Facebook links
- No external libraries required

Next improvements can include:
- CJ Farm logo and real farm photos
- Individual animal profiles
- Contact/donation page
- Events calendar
- Volunteer page
- About the nonprofit
- Online donation button
- Custom domain and SEO/social preview
